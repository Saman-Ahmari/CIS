/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: samanahmari
 *
 * Created on February 26, 2019, 9:29 PM
 */

#include <iostream>

using namespace std;

int main() 
{
    
    char c;
    cout << "Press return after entering a letter. \n";
    
    cin >> c;
    
    cout << "\n";
    cout << "\n";
    
    cout <<" "<<" "<<c<<" "<<c<<" "<<c<<"\n";
    cout <<" "<<c<<" "<<" "<<" "<<" "<<c<<"\n";
    cout <<c<<"\n";
    cout <<c<<"\n";
    cout <<c<<"\n";
    cout <<c<<"\n";
    cout <<c<<"\n";
    cout <<" "<<c<<" "<<" "<<" "<<" "<<c<<"\n";
    cout <<" "<<" "<<c<<" "<<c<<" "<<c<<"\n";
    cout << "\n";
    
    
 

    
    
    
    

    return 0;
}

