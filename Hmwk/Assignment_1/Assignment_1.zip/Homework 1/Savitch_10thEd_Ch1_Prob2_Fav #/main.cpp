/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: samanahmari
 *
 * Created on February 25, 2019, 10:16 PM
 */

#include <iostream>
using namespace std;

int main() 
{
    int favorite_number;
    
    cout << "Press return after entering a number.\n";
    cout << "Enter your favorite number:\n";
    cin >> favorite_number;
    cout << "Your favorite number is ";
    cout << favorite_number;
    cout << ".";
    
    return 0;
}

