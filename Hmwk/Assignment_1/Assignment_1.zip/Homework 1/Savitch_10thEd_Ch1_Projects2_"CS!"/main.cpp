/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: samanahmari
 *
 * Created on February 26, 2019, 1:36 AM
 */

#include <iostream>
using namespace std;

int main() 
{
    cout << "*******************************************\n";
    cout << " \n";
    cout << "       C C C            S S S S       !!   \n";
    cout << "     C       C        S         S     !!   \n";
    cout << "    C                S                !!   \n";
    cout << "   C                  S               !!   \n";
    cout << "   C                    S S S S       !!   \n";
    cout << "   C                            S     !!   \n";
    cout << "    C                            S    !!   \n";
    cout << "     C       C        S         S          \n";
    cout << "       C C C            S S S S       00   \n";
    cout << " \n";
    cout << "*******************************************\n";
    cout << " \n";
    cout << "    Computer Science is Cool Stuff!!!      \n";
    return 0;
}

